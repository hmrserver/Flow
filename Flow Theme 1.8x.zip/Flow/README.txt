hey guys
For viewing flow theme's feature/Installation/Customization/Credits view its Documentation HTML File

A special thanks goes to Mybb Team for creating such an awesome Forum Script.
thanks for using Flow theme :)
Please share this theme further if you really liked the theme